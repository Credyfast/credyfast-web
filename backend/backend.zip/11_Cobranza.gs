// ============================================================
// CredyFast — 11_Cobranza.gs
// Módulo de Cobranza en Campo.
// - Ruta del día: clientes con atraso
// - Control de responsable por cobro
// - Alerta si no se deposita en 24h
// ============================================================

const Cobranza = (() => {

  /**
   * Ruta del día: créditos con Estado_Operativo != AL_CORRIENTE
   * Enriquecidos con datos del cliente y coordenadas para Maps.
   */
  function getRuta(ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.COBRANZA);

      const creditos = SheetHelper.getAll(CONFIG.SHEETS.CREDITOS)
        .filter(cr => cr['Estado'] === 'ACTIVO' &&
                      ['ATRASO_LEVE','ATRASO_CRITICO'].includes(cr['Estado_Operativo']));

      const ruta = creditos.map(cr => {
        const clienteFound = SheetHelper.findOne(CONFIG.SHEETS.CLIENTES, c => c['ID_Cliente'] === cr['ID_Cliente']);
        const cliente = clienteFound ? clienteFound.data : {};

        // Próxima cuota a cobrar
        const pagosRows = SheetHelper.findRows(CONFIG.SHEETS.PAGOS,
          p => p['ID_Credito'] === cr['ID_Credito'] &&
               parseFloat(p['Monto_Pagado'] || 0) < parseFloat(p['Monto_Esperado'])
        ).sort((a, b) => a.data['Num_Semana'] - b.data['Num_Semana']);

        const proximaCuota = pagosRows.length > 0 ? pagosRows[0].data : null;

        return {
          idCredito:      cr['ID_Credito'],
          idCliente:      cr['ID_Cliente'],
          nombre:         (cliente['Nombre'] || '') + ' ' + (cliente['Apellido_Paterno'] || ''),
          telefono:       cliente['Telefono_Principal'] || '',
          direccion:      (cliente['Calle_Numero'] || '') + ', ' + (cliente['Colonia'] || ''),
          lat:            cliente['Coordenadas_Lat'] || '',
          lng:            cliente['Coordenadas_Lng'] || '',
          estadoOperativo:cr['Estado_Operativo'],
          saldoPendiente: cr['Saldo_Pendiente'],
          proximaCuota:   proximaCuota ? {
            semana:    proximaCuota['Num_Semana'],
            vence:     proximaCuota['Fecha_Vencimiento'],
            monto:     proximaCuota['Monto_Esperado'],
            pagado:    proximaCuota['Monto_Pagado'],
            faltante:  _round2(parseFloat(proximaCuota['Monto_Esperado']) - parseFloat(proximaCuota['Monto_Pagado'] || 0)),
          } : null,
        };
      });

      // Primero ATRASO_CRITICO
      ruta.sort((a, b) => {
        const orden = { ATRASO_CRITICO: 0, ATRASO_LEVE: 1 };
        return (orden[a.estadoOperativo] || 9) - (orden[b.estadoOperativo] || 9);
      });

      return { ok: true, data: ruta, total: ruta.length };
    } catch (err) { return handleError_(err); }
  }

  /**
   * Lista cobros pendientes de depósito asignados a este cobranza.
   */
  function getPendientes(ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.COBRANZA);
      const responsableId = ctx.user.id || ctx.user.username;
      const pendientes = SheetHelper.getAll(CONFIG.SHEETS.COBRANZA)
        .filter(c => c['Estado'] === 'PENDIENTE_DEPOSITO' && c['Responsable_ID'] === responsableId);
      return { ok: true, data: pendientes };
    } catch (err) { return handleError_(err); }
  }

  /**
   * Verificar y generar alertas de cobros sin depositar en 24h.
   * Ejecutado por Supervisor/SuperUsuario o como trigger automático.
   */
  function checkAlertas(ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPERVISOR);
      const ahora = new Date();
      const all = SheetHelper.getAll(CONFIG.SHEETS.COBRANZA);

      const alertas = [];
      all.forEach((cob, i) => {
        if (cob['Estado'] !== 'PENDIENTE_DEPOSITO') return;

        const fechaLimite = new Date(cob['Fecha_Limite_Dep']);
        if (ahora > fechaLimite) {
          // Marcar como ALERTA si no ya estaba
          const cobFound = SheetHelper.findOne(CONFIG.SHEETS.COBRANZA, r => r['ID_Cobranza'] === cob['ID_Cobranza']);
          if (cobFound && cobFound.data['Estado'] === 'PENDIENTE_DEPOSITO') {
            SheetHelper.updateRow(CONFIG.SHEETS.COBRANZA, cobFound.rowIndex, { 'Estado': 'ALERTA' });
          }
          alertas.push({
            idCobranza:   cob['ID_Cobranza'],
            idCredito:    cob['ID_Credito'],
            responsable:  cob['Responsable_ID'],
            monto:        cob['Monto_Cobrado'],
            fechaCobro:   cob['Fecha_Cobro'],
            fechaLimite:  cob['Fecha_Limite_Dep'],
            horasAtraso:  _round2((ahora - fechaLimite) / (1000 * 60 * 60)),
          });
        }
      });

      return { ok: true, alertas, total: alertas.length };
    } catch (err) { return handleError_(err); }
  }

  function _round2(n) { return Math.round(n * 100) / 100; }

  return { getRuta, getPendientes, checkAlertas };
})();

// ── Trigger automático para verificar alertas ─────────────────
// Registrar en GAS como trigger basado en tiempo (cada hora):
//   Triggers → Añadir trigger → cobranzaAlertaTrigger → Por tiempo → Cada hora
function cobranzaAlertaTrigger() {
  // Contexto de sistema para el log
  const ctx = { user: { id: 'SYSTEM', username: 'SISTEMA', rol: 'SuperUsuario' }, ip: 'TRIGGER' };
  Cobranza.checkAlertas(ctx);
}
