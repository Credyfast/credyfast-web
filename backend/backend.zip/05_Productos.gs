// ============================================================
// CredyFast — 05_Productos.gs
// Gestión de catálogo de productos.
// ============================================================

const Productos = (() => {

  function create(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPER_USUARIO);
      _validate(payload);

      const lock = LockService.getScriptLock();
      lock.waitLock(10000);
      try {
        const id  = SheetHelper.nextId(CONFIG.SHEETS.PRODUCTOS, 'IDP', 5);
        const now = _now();
        const pagoSemanal       = _round2(payload.precioCredito / payload.totalSemanas);
        const tasaImplicita     = _round2((payload.precioCredito - payload.precioContado) / payload.precioContado);

        SheetHelper.insertRow(CONFIG.SHEETS.PRODUCTOS, {
          'ID_Producto':            id,
          'Nombre':                 payload.nombre,
          'Descripcion':            payload.descripcion || '',
          'Categoria':              payload.categoria || 'Otro',
          'Marca':                  payload.marca || '',
          'Modelo':                 payload.modelo || '',
          'Costo_Producto':         payload.costoProducto,
          'Precio_Contado':         payload.precioContado,
          'Precio_Credito':         payload.precioCredito,
          'Total_Semanas':          payload.totalSemanas,
          'Pago_Semanal':           pagoSemanal,
          'Tasa_Interes_Implicita': tasaImplicita,
          'Stock_Disponible':       payload.stock || 0,
          'Stock_Minimo':           payload.stockMinimo || 0,
          'Numero_Serie':           payload.numeroSerie || '',
          'Proveedor':              payload.proveedor || '',
          'Activo':                 'TRUE',
          'Fecha_Creacion':         now,
          'Creado_Por':             ctx.user.id || ctx.user.username,
          'Fecha_Modificacion':     now,
          'Modificado_Por':         ctx.user.id || ctx.user.username,
          'Imagen_Drive_ID':        '',
        });

        _log(ctx, 'PRODUCTO_CREAR', id, {}, 'EXITO');
        return { ok: true, id, pagoSemanal, message: `Producto "${payload.nombre}" creado.` };

      } finally { lock.releaseLock(); }
    } catch (err) { return handleError_(err); }
  }

  function update(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPER_USUARIO);
      const { id } = payload;
      if (!id) throw { code: 'DATOS_INVALIDOS', message: 'ID de producto requerido.' };

      const found = SheetHelper.findOne(CONFIG.SHEETS.PRODUCTOS, r => r['ID_Producto'] === id);
      if (!found) throw { code: 'NO_ENCONTRADO', message: 'Producto no encontrado.' };

      _validate(payload);

      const pagoSemanal = _round2(payload.precioCredito / payload.totalSemanas);
      const tasa        = _round2((payload.precioCredito - payload.precioContado) / payload.precioContado);

      SheetHelper.updateRow(CONFIG.SHEETS.PRODUCTOS, found.rowIndex, {
        'Nombre':                 payload.nombre,
        'Descripcion':            payload.descripcion || '',
        'Categoria':              payload.categoria || 'Otro',
        'Marca':                  payload.marca || '',
        'Modelo':                 payload.modelo || '',
        'Costo_Producto':         payload.costoProducto,
        'Precio_Contado':         payload.precioContado,
        'Precio_Credito':         payload.precioCredito,
        'Total_Semanas':          payload.totalSemanas,
        'Pago_Semanal':           pagoSemanal,
        'Tasa_Interes_Implicita': tasa,
        'Stock_Disponible':       payload.stock !== undefined ? payload.stock : found.data['Stock_Disponible'],
        'Stock_Minimo':           payload.stockMinimo !== undefined ? payload.stockMinimo : found.data['Stock_Minimo'],
        'Fecha_Modificacion':     _now(),
        'Modificado_Por':         ctx.user.id || ctx.user.username,
      });

      _log(ctx, 'PRODUCTO_EDITAR', id, { pagoSemanal }, 'EXITO');
      return { ok: true, pagoSemanal, message: 'Producto actualizado.' };

    } catch (err) { return handleError_(err); }
  }

  function list(ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPERVISOR);
      const all = SheetHelper.getAll(CONFIG.SHEETS.PRODUCTOS);
      return { ok: true, data: all };
    } catch (err) { return handleError_(err); }
  }

  function toggle(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPER_USUARIO);
      const { id } = payload;
      const found = SheetHelper.findOne(CONFIG.SHEETS.PRODUCTOS, r => r['ID_Producto'] === id);
      if (!found) throw { code: 'NO_ENCONTRADO', message: 'Producto no encontrado.' };

      // No desactivar si tiene créditos ACTIVOS
      if (found.data['Activo'] === true || found.data['Activo'] === 'TRUE') {
        const creditoActivo = SheetHelper.findOne(CONFIG.SHEETS.CREDITOS,
          r => r['ID_Producto'] === id && r['Estado'] === 'ACTIVO');
        if (creditoActivo) throw { code: 'TIENE_CREDITOS_ACTIVOS', message: 'No se puede desactivar: tiene créditos activos.' };
      }

      const nuevoEstado = (found.data['Activo'] === true || found.data['Activo'] === 'TRUE') ? 'FALSE' : 'TRUE';
      SheetHelper.updateRow(CONFIG.SHEETS.PRODUCTOS, found.rowIndex, { 'Activo': nuevoEstado });
      return { ok: true, message: `Producto ${nuevoEstado === 'TRUE' ? 'activado' : 'desactivado'}.` };

    } catch (err) { return handleError_(err); }
  }

  function _validate(p) {
    if (!p.nombre || !p.precioContado || !p.precioCredito || !p.totalSemanas || !p.costoProducto) {
      throw { code: 'DATOS_INVALIDOS', message: 'Faltan campos requeridos del producto.' };
    }
    if (!(p.costoProducto < p.precioContado && p.precioContado < p.precioCredito)) {
      throw { code: 'PRECIOS_INVALIDOS', message: 'Debe cumplirse: Costo < Precio_Contado < Precio_Crédito.' };
    }
    if (p.totalSemanas < 4 || p.totalSemanas > 104) {
      throw { code: 'SEMANAS_INVALIDAS', message: 'Total de semanas debe ser entre 4 y 104.' };
    }
  }

  function _round2(n) { return Math.round(n * 100) / 100; }
  function _now() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'); }

  function _log(ctx, accion, id, detalle, resultado) {
    try {
      SheetHelper.insertRow(CONFIG.SHEETS.LOGS, {
        'ID_Log': 'LOG' + Date.now(), 'Timestamp': _now(),
        'Usuario_ID': ctx.user.id || '', 'Username': ctx.user.username || '',
        'Accion': accion, 'Modulo': 'PRODUCTOS', 'ID_Registro_Afectado': id,
        'Estado_Anterior': '', 'Estado_Nuevo': JSON.stringify(detalle),
        'IP_Origen': ctx.ip || '', 'Resultado': resultado, 'Detalle_Error': '',
      });
    } catch(_) {}
  }

  return { create, update, list, toggle };
})();
