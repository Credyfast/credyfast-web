// ============================================================
// CredyFast — 01_Router.gs
// Punto de entrada único: doPost(e)
// Enruta cada acción al handler correspondiente.
// ============================================================

function doPost(e) {
  try {
    const body    = JSON.parse(e.postData.contents);
    const action  = body.action  || '';
    const token   = body.token   || '';
    const payload = body.payload || {};
    const ip      = getClientIP_(e);

    // Acciones públicas (sin autenticación)
    if (action === 'auth_login') {
      return jsonResponse_(Auth.login(payload, ip));
    }

    // Todas las demás requieren sesión válida
    const session = Auth.validateSession(token);
    if (!session.ok) {
      return jsonResponse_({ ok: false, error: 'SESION_INVALIDA', message: 'Sesión expirada o inválida. Inicia sesión nuevamente.' });
    }

    const ctx = { user: session.user, ip };

    // ── Router principal ────────────────────────────────────
    switch (action) {
      // Auth
      case 'auth_logout':         return jsonResponse_(Auth.logout(token, ctx));

      // Usuarios
      case 'user_create':         return jsonResponse_(Usuarios.create(payload, ctx));
      case 'user_list':           return jsonResponse_(Usuarios.list(ctx));
      case 'user_toggle':         return jsonResponse_(Usuarios.toggle(payload, ctx));

      // Productos
      case 'product_create':      return jsonResponse_(Productos.create(payload, ctx));
      case 'product_update':      return jsonResponse_(Productos.update(payload, ctx));
      case 'product_list':        return jsonResponse_(Productos.list(ctx));
      case 'product_toggle':      return jsonResponse_(Productos.toggle(payload, ctx));

      // Clientes
      case 'client_create':       return jsonResponse_(Clientes.create(payload, ctx));
      case 'client_update':       return jsonResponse_(Clientes.update(payload, ctx));
      case 'client_search':       return jsonResponse_(Clientes.search(payload, ctx));
      case 'client_get':          return jsonResponse_(Clientes.get(payload, ctx));
      case 'client_upload_doc':   return jsonResponse_(Clientes.uploadDoc(payload, ctx));

      // Créditos
      case 'credit_request':      return jsonResponse_(Creditos.request(payload, ctx));
      case 'credit_approve':      return jsonResponse_(Creditos.approve(payload, ctx));
      case 'credit_reject':       return jsonResponse_(Creditos.reject(payload, ctx));
      case 'credit_list':         return jsonResponse_(Creditos.list(payload, ctx));
      case 'credit_get':          return jsonResponse_(Creditos.get(payload, ctx));

      // Pagos (Motor)
      case 'payment_register':    return jsonResponse_(Pagos.register(payload, ctx));
      case 'payment_field':       return jsonResponse_(Pagos.registerField(payload, ctx));
      case 'payment_confirm':     return jsonResponse_(Pagos.confirmDeposit(payload, ctx));
      case 'payment_schedule':    return jsonResponse_(Pagos.getSchedule(payload, ctx));

      // Caja
      case 'caja_balance':        return jsonResponse_(Caja.getBalance(ctx));
      case 'caja_withdrawal':     return jsonResponse_(Caja.withdrawal(payload, ctx));
      case 'caja_movements':      return jsonResponse_(Caja.movements(payload, ctx));

      // Arqueo
      case 'caja_arqueo':         return jsonResponse_(Arqueo.realizar(payload, ctx));
      case 'caja_arqueo_history': return jsonResponse_(Arqueo.history(ctx));

      // Cobranza
      case 'cobranza_ruta':       return jsonResponse_(Cobranza.getRuta(ctx));
      case 'cobranza_pendientes': return jsonResponse_(Cobranza.getPendientes(ctx));
      case 'cobranza_alertas':    return jsonResponse_(Cobranza.checkAlertas(ctx));

      // Contratos y Tickets
      case 'contract_generate':   return jsonResponse_(Contratos.generate(payload, ctx));
      case 'ticket_generate':     return jsonResponse_(Tickets.generate(payload, ctx));

      // Dashboard
      case 'dashboard_data':      return jsonResponse_(Dashboard.getData(ctx));

      // Score
      case 'score_get':           return jsonResponse_(Score.get(payload, ctx));

      // Logs
      case 'log_list':            return jsonResponse_(LogsSistema.list(payload, ctx));

      default:
        return jsonResponse_({ ok: false, error: 'ACCION_DESCONOCIDA', message: `Acción no reconocida: ${action}` });
    }

  } catch (err) {
    Logger.log('ROUTER_ERROR: ' + err.message + '\n' + err.stack);
    return jsonResponse_({ ok: false, error: 'SERVER_ERROR', message: 'Error interno del servidor.' });
  }
}

// ── Helpers globales ─────────────────────────────────────────

function jsonResponse_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

function getClientIP_(e) {
  try { return e.parameter['X-Forwarded-For'] || ''; } catch(_) { return ''; }
}

/**
 * Verifica que el rol del usuario tenga nivel >= al mínimo requerido.
 * @param {string} userRole  - Rol actual del usuario
 * @param {string} minRole   - Rol mínimo requerido
 */
function requireRole_(userRole, minRole) {
  const levels = CONFIG.ROLE_LEVEL;
  if ((levels[userRole] || 0) < (levels[minRole] || 999)) {
    throw { code: 'SIN_PERMISO', message: `Se requiere rol ${minRole} o superior.` };
  }
}

/**
 * Convierte error de throw a respuesta estándar.
 */
function handleError_(err) {
  if (err && err.code) {
    return { ok: false, error: err.code, message: err.message };
  }
  Logger.log('UNHANDLED: ' + JSON.stringify(err));
  return { ok: false, error: 'ERROR_INTERNO', message: 'Operación fallida.' };
}
