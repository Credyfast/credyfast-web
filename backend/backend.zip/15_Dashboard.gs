// ============================================================
// CredyFast — 15_Dashboard.gs
// Dashboard en tiempo real (calculado en backend).
// ============================================================

const Dashboard = (() => {

  function getData(ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPERVISOR);
      const hoy = _today();

      // ── Saldo de caja ──────────────────────────────────────
      const saldoCaja = parseFloat(
        SheetHelper.getLastColumnValue(CONFIG.SHEETS.CAJA, 7) || 0
      );

      // ── Créditos ──────────────────────────────────────────
      const todosLosCreditos = SheetHelper.getAll(CONFIG.SHEETS.CREDITOS);
      const creditosActivos    = todosLosCreditos.filter(c => c['Estado'] === 'ACTIVO').length;
      const creditosFinalizados= todosLosCreditos.filter(c => c['Estado'] === 'FINALIZADO').length;
      const creditosInconclusos= todosLosCreditos.filter(c => c['Estado'] === 'INCONCLUSO').length;
      const creditosPendientes = todosLosCreditos.filter(c => c['Estado'] === 'PENDIENTE').length;

      const atrasoLeve    = todosLosCreditos.filter(c => c['Estado_Operativo'] === 'ATRASO_LEVE').length;
      const atrasoCritico = todosLosCreditos.filter(c => c['Estado_Operativo'] === 'ATRASO_CRITICO').length;

      // ── Ingresos ──────────────────────────────────────────
      const movimientosCaja = SheetHelper.getAll(CONFIG.SHEETS.CAJA)
        .filter(m => m['Tipo'] === 'INGRESO_PAGO');

      const hoyStr      = hoy;
      const semanaStr   = _startOfWeek(hoy);
      const mesStr      = hoy.substring(0, 7);     // 'YYYY-MM'

      const ingresosHoy  = movimientosCaja
        .filter(m => (m['Fecha'] || '').startsWith(hoyStr))
        .reduce((sum, m) => sum + parseFloat(m['Monto'] || 0), 0);

      const ingresosSemana = movimientosCaja
        .filter(m => (m['Fecha'] || '') >= semanaStr && (m['Fecha'] || '') <= hoyStr + ' 99:99')
        .reduce((sum, m) => sum + parseFloat(m['Monto'] || 0), 0);

      const ingresosMes = movimientosCaja
        .filter(m => (m['Fecha'] || '').startsWith(mesStr))
        .reduce((sum, m) => sum + parseFloat(m['Monto'] || 0), 0);

      // ── Cobros pendientes de depósito ─────────────────────
      const cobranzeAll  = SheetHelper.getAll(CONFIG.SHEETS.COBRANZA);
      const pendDeposito = cobranzeAll.filter(c => c['Estado'] === 'PENDIENTE_DEPOSITO').length;
      const alertas24h   = cobranzeAll.filter(c => c['Estado'] === 'ALERTA').length;

      // ── Top clientes morosos ──────────────────────────────
      const scoresAll    = SheetHelper.getAll(CONFIG.SHEETS.SCORE_CLIENTE);
      const topMorosos   = scoresAll
        .filter(s => s['Clasificacion'] === 'RIESGOSO' || s['Pagos_Morosos'] > 0)
        .sort((a, b) => parseFloat(b['Pagos_Morosos'] || 0) - parseFloat(a['Pagos_Morosos'] || 0))
        .slice(0, 5)
        .map(s => ({
          idCliente:   s['ID_Cliente'],
          pagosMorosos:s['Pagos_Morosos'],
          score:       s['Score_Raw'],
          clasificacion: s['Clasificacion'],
        }));

      // ── Cartera total ──────────────────────────────────────
      const carteraTotal = todosLosCreditos
        .filter(c => c['Estado'] === 'ACTIVO')
        .reduce((sum, c) => sum + parseFloat(c['Saldo_Pendiente'] || 0), 0);

      return {
        ok: true,
        timestamp: _now(),
        caja: {
          saldoActual:   _round2(saldoCaja),
        },
        creditos: {
          activos:       creditosActivos,
          finalizados:   creditosFinalizados,
          inconclusos:   creditosInconclusos,
          pendientes:    creditosPendientes,
          atrasoLeve,
          atrasoCritico,
        },
        ingresos: {
          hoy:    _round2(ingresosHoy),
          semana: _round2(ingresosSemana),
          mes:    _round2(ingresosMes),
        },
        cobranza: {
          pendientesDeposito: pendDeposito,
          alertas24h,
        },
        carteraTotal: _round2(carteraTotal),
        topMorosos,
      };

    } catch (err) { return handleError_(err); }
  }

  // ── Helpers ───────────────────────────────────────────────

  /** Retorna el lunes de la semana actual (yyyy-MM-dd). */
  function _startOfWeek(hoy) {
    const d = new Date(hoy + 'T00:00:00');
    const dow = d.getDay(); // 0=Dom
    const diff = dow === 0 ? -6 : 1 - dow;
    d.setDate(d.getDate() + diff);
    return Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM-dd');
  }

  function _round2(n) { return Math.round(n * 100) / 100; }
  function _today() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd'); }
  function _now() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'); }

  return { getData };
})();
