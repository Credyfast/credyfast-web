// ============================================================
// CredyFast — 06_Clientes.gs
// Gestión de clientes y carga de documentos a Drive.
// ============================================================

const Clientes = (() => {

  function create(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.VENDEDOR);
      _validateClient(payload);

      const lock = LockService.getScriptLock();
      lock.waitLock(15000);
      try {
        // CURP único
        const curpExistente = SheetHelper.findOne(CONFIG.SHEETS.CLIENTES, r => r['CURP'] === payload.curp);
        if (curpExistente) throw { code: 'CURP_DUPLICADO', message: 'Ya existe un cliente con ese CURP.' };

        const id  = SheetHelper.nextId(CONFIG.SHEETS.CLIENTES, 'IDC', 5);
        const now = _now();

        // Crear carpeta en Drive
        const clientFolder = DriveApp
          .getFolderById(CONFIG.DRIVE_CLIENTES_FOLDER_ID)
          .createFolder(id + '_' + payload.nombre + '_' + payload.apellidoPaterno);
        const folderId = clientFolder.getId();

        SheetHelper.insertRow(CONFIG.SHEETS.CLIENTES, {
          'ID_Cliente':          id,
          'Nombre':              payload.nombre,
          'Apellido_Paterno':    payload.apellidoPaterno,
          'Apellido_Materno':    payload.apellidoMaterno || '',
          'CURP':                payload.curp.toUpperCase(),
          'Fecha_Nacimiento':    payload.fechaNacimiento,
          'Sexo':                payload.sexo,
          'Telefono_Principal':  payload.telefonoPrincipal,
          'Telefono_Secundario': payload.telefonoSecundario || '',
          'Calle_Numero':        payload.calleNumero,
          'Colonia':             payload.colonia,
          'Ciudad':              payload.ciudad,
          'Estado':              payload.estado,
          'CP':                  payload.cp,
          'Coordenadas_Lat':     payload.lat || '',
          'Coordenadas_Lng':     payload.lng || '',
          'Ref1_Nombre':         payload.ref1Nombre,
          'Ref1_Telefono':       payload.ref1Telefono,
          'Ref1_Relacion':       payload.ref1Relacion,
          'Ref2_Nombre':         payload.ref2Nombre || '',
          'Ref2_Telefono':       payload.ref2Telefono || '',
          'Ref2_Relacion':       payload.ref2Relacion || '',
          'Drive_Folder_ID':     folderId,
          'INE_Frente_ID':       '',
          'INE_Reverso_ID':      '',
          'Comprobante_ID':      '',
          'Documentos_Completos':'FALSE',
          'Vendedor_ID':         ctx.user.id || ctx.user.username,
          'Fecha_Registro':      now,
          'Activo':              'TRUE',
          'Notas':               payload.notas || '',
        });

        _log(ctx, 'CLIENTE_CREAR', id, { curp: payload.curp }, 'EXITO');
        return { ok: true, id, folderId, message: `Cliente "${payload.nombre}" registrado correctamente.` };

      } finally { lock.releaseLock(); }
    } catch (err) { return handleError_(err); }
  }

  function update(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.VENDEDOR);
      const { id } = payload;
      const found = SheetHelper.findOne(CONFIG.SHEETS.CLIENTES, r => r['ID_Cliente'] === id);
      if (!found) throw { code: 'NO_ENCONTRADO', message: 'Cliente no encontrado.' };

      // Solo editar campos permitidos (no CURP, no IDs de Drive)
      const updates = {};
      ['Nombre','Apellido_Paterno','Apellido_Materno','Telefono_Principal','Telefono_Secundario',
       'Calle_Numero','Colonia','Ciudad','Estado','CP','Coordenadas_Lat','Coordenadas_Lng',
       'Ref1_Nombre','Ref1_Telefono','Ref1_Relacion','Ref2_Nombre','Ref2_Telefono','Ref2_Relacion','Notas']
        .forEach(campo => {
          const key = _camelToSnake(campo);
          if (payload[key] !== undefined) updates[campo] = payload[key];
        });

      SheetHelper.updateRow(CONFIG.SHEETS.CLIENTES, found.rowIndex, updates);
      _log(ctx, 'CLIENTE_EDITAR', id, updates, 'EXITO');
      return { ok: true, message: 'Cliente actualizado.' };

    } catch (err) { return handleError_(err); }
  }

  function search(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.VENDEDOR);
      const { q } = payload;
      if (!q || q.length < 2) throw { code: 'BUSQUEDA_INVALIDA', message: 'Mínimo 2 caracteres.' };

      const term = q.toLowerCase();
      const all  = SheetHelper.getAll(CONFIG.SHEETS.CLIENTES);
      const results = all.filter(r =>
        r['Activo'] === true || r['Activo'] === 'TRUE'
      ).filter(r =>
        (r['Nombre'] + ' ' + r['Apellido_Paterno']).toLowerCase().includes(term) ||
        r['CURP'].toLowerCase().includes(term) ||
        r['Telefono_Principal'].includes(term) ||
        r['ID_Cliente'].toLowerCase().includes(term)
      ).slice(0, 20);

      return { ok: true, data: results };
    } catch (err) { return handleError_(err); }
  }

  function get(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.VENDEDOR);
      const { id } = payload;
      const found = SheetHelper.findOne(CONFIG.SHEETS.CLIENTES, r => r['ID_Cliente'] === id);
      if (!found) throw { code: 'NO_ENCONTRADO', message: 'Cliente no encontrado.' };
      return { ok: true, data: found.data };
    } catch (err) { return handleError_(err); }
  }

  /**
   * Carga de documento (INE frente, INE reverso, comprobante) a Google Drive.
   * payload: { id_cliente, tipo: 'ine_frente'|'ine_reverso'|'comprobante', base64, mimeType }
   */
  function uploadDoc(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.VENDEDOR);
      const { idCliente, tipo, base64, mimeType } = payload;

      const TIPOS_VALIDOS = { ine_frente: 'INE_Frente_ID', ine_reverso: 'INE_Reverso_ID', comprobante: 'Comprobante_ID' };
      if (!TIPOS_VALIDOS[tipo]) throw { code: 'TIPO_INVALIDO', message: 'Tipo de documento inválido.' };

      const found = SheetHelper.findOne(CONFIG.SHEETS.CLIENTES, r => r['ID_Cliente'] === idCliente);
      if (!found) throw { code: 'NO_ENCONTRADO', message: 'Cliente no encontrado.' };

      const folder     = DriveApp.getFolderById(found.data['Drive_Folder_ID']);
      const blob       = Utilities.newBlob(Utilities.base64Decode(base64), mimeType, tipo + '.jpg');
      const file       = folder.createFile(blob);
      const fileId     = file.getId();

      // Actualizar columna correspondiente
      const updates = { [TIPOS_VALIDOS[tipo]]: fileId };

      // Verificar si los 3 documentos están completos
      const docActualizado = Object.assign({}, found.data, updates);
      const completos = !!(docActualizado['INE_Frente_ID'] && docActualizado['INE_Reverso_ID'] && docActualizado['Comprobante_ID']);
      updates['Documentos_Completos'] = completos ? 'TRUE' : 'FALSE';

      SheetHelper.updateRow(CONFIG.SHEETS.CLIENTES, found.rowIndex, updates);
      return { ok: true, fileId, documentosCompletos: completos, message: `Documento "${tipo}" cargado.` };

    } catch (err) { return handleError_(err); }
  }

  // ── Validaciones ──────────────────────────────────────────

  function _validateClient(p) {
    const required = ['nombre','apellidoPaterno','curp','fechaNacimiento','sexo',
                      'telefonoPrincipal','calleNumero','colonia','ciudad','estado','cp',
                      'ref1Nombre','ref1Telefono','ref1Relacion'];
    const missing = required.filter(f => !p[f]);
    if (missing.length) throw { code: 'DATOS_INVALIDOS', message: `Campos requeridos faltantes: ${missing.join(', ')}` };

    if (!/^[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d$/.test(p.curp.toUpperCase())) {
      throw { code: 'CURP_INVALIDO', message: 'Formato de CURP inválido.' };
    }
    if (!/^\d{10}$/.test(p.telefonoPrincipal)) {
      throw { code: 'TEL_INVALIDO', message: 'Teléfono principal debe tener 10 dígitos.' };
    }
    if (!['M','F'].includes(p.sexo)) {
      throw { code: 'SEXO_INVALIDO', message: 'Sexo debe ser M o F.' };
    }

    // Edad 18-80
    const nacimiento = new Date(p.fechaNacimiento);
    const hoy = new Date();
    const edad = (hoy - nacimiento) / (1000 * 60 * 60 * 24 * 365.25);
    if (edad < 18 || edad > 80) throw { code: 'EDAD_INVALIDA', message: 'El cliente debe tener entre 18 y 80 años.' };
  }

  function _camelToSnake(str) {
    return str.replace(/([A-Z])/g, '_$1').replace(/^_/, '');
  }
  function _now() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'); }

  function _log(ctx, accion, id, detalle, resultado) {
    try {
      SheetHelper.insertRow(CONFIG.SHEETS.LOGS, {
        'ID_Log': 'LOG' + Date.now(), 'Timestamp': _now(),
        'Usuario_ID': ctx.user.id || '', 'Username': ctx.user.username || '',
        'Accion': accion, 'Modulo': 'CLIENTES', 'ID_Registro_Afectado': id,
        'Estado_Anterior': '', 'Estado_Nuevo': JSON.stringify(detalle),
        'IP_Origen': ctx.ip || '', 'Resultado': resultado, 'Detalle_Error': '',
      });
    } catch(_) {}
  }

  return { create, update, search, get, uploadDoc };
})();
