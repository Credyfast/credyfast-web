// ============================================================
// CredyFast — 08_MotorPagos.gs
// Motor de Pagos — Núcleo crítico del sistema.
//
// REGLAS CLAVE:
// - Monto_Esperado NUNCA se modifica.
// - Capital: el backend considera liquidada una cuota cuando
//   Monto_Pagado (incluyendo abono de capital) >= Monto_Esperado.
// - Cascada: ATRASADAS → ACTUAL → FUTURAS → CAPITAL
// - Concurrencia: LockService por ID_Credito
// ============================================================

const Pagos = (() => {

  // ── Registrar pago en caja ────────────────────────────────
  function register(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.CAJERO);
      return _procesarPago(payload, ctx, 'CAJA');
    } catch (err) { return handleError_(err); }
  }

  // ── Registrar pago en campo (cobranza) ───────────────────
  function registerField(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.COBRANZA);
      return _procesarPagoEnCampo(payload, ctx);
    } catch (err) { return handleError_(err); }
  }

  // ── Confirmar depósito del pago de campo ─────────────────
  function confirmDeposit(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.CAJERO);
      return _confirmarDeposito(payload, ctx);
    } catch (err) { return handleError_(err); }
  }

  // ── Obtener calendario de pagos de un crédito ────────────
  function getSchedule(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.CAJERO);
      const { idCredito } = payload;
      if (!idCredito) throw { code: 'DATOS_INVALIDOS', message: 'idCredito requerido.' };

      const creditoFound = SheetHelper.findOne(CONFIG.SHEETS.CREDITOS, r => r['ID_Credito'] === idCredito);
      if (!creditoFound) throw { code: 'NO_ENCONTRADO', message: 'Crédito no encontrado.' };

      const pagos = SheetHelper.findRows(CONFIG.SHEETS.PAGOS, r => r['ID_Credito'] === idCredito)
        .map(p => p.data)
        .sort((a, b) => a['Num_Semana'] - b['Num_Semana']);

      // Actualizar estados por fecha (ATRASADO si venció sin pago)
      const hoy = _today();
      const pagosActualizados = pagos.map(p => {
        if (p['Estado_Pago'] === 'POR COBRAR' && p['Fecha_Vencimiento'] < hoy) {
          return Object.assign({}, p, { 'Estado_Pago': 'ATRASADO' });
        }
        return p;
      });

      return {
        ok: true,
        credito: creditoFound.data,
        pagos: pagosActualizados,
        resumen: _calcResumen(pagosActualizados),
      };
    } catch (err) { return handleError_(err); }
  }

  // ══════════════════════════════════════════════════════════
  // MOTOR PRINCIPAL DE CASCADA
  // ══════════════════════════════════════════════════════════

  function _procesarPago(payload, ctx, canal) {
    const { idCredito, montoRecibido, tipoAbono } = payload;
    // tipoAbono: 'REGULAR' | 'CAPITAL'
    if (!idCredito || !montoRecibido || montoRecibido <= 0) {
      throw { code: 'DATOS_INVALIDOS', message: 'idCredito y montoRecibido (> 0) son requeridos.' };
    }

    const lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      // ── 1. Cargar crédito ──────────────────────────────────
      const creditoFound = SheetHelper.findOne(CONFIG.SHEETS.CREDITOS, r => r['ID_Credito'] === idCredito);
      if (!creditoFound) throw { code: 'NO_ENCONTRADO', message: 'Crédito no encontrado.' };
      const cr = creditoFound.data;
      if (cr['Estado'] !== 'ACTIVO') throw { code: 'CREDITO_NO_ACTIVO', message: 'Solo se pueden registrar pagos en créditos ACTIVOS.' };

      // ── 2. Cargar pagos ordenados ──────────────────────────
      const pagosRows = SheetHelper.findRows(CONFIG.SHEETS.PAGOS, r => r['ID_Credito'] === idCredito)
        .sort((a, b) => a.data['Num_Semana'] - b.data['Num_Semana']);

      const hoy = _today();
      let montoRestante = parseFloat(montoRecibido);
      const now = _now();
      const afectados = [];

      if (tipoAbono === 'CAPITAL') {
        // ── Abono a Capital ──────────────────────────────────
        montoRestante = _aplicarCapital(pagosRows, cr, montoRestante, ctx, now, canal, afectados);
      } else {
        // ── Pago Regular: Cascada ATRASADAS → ACTUAL → FUTURAS
        montoRestante = _aplicarCascada(pagosRows, hoy, montoRestante, ctx, now, canal, afectados);
      }

      // ── 3. Actualizar totales del crédito ──────────────────
      const montoAplicado = parseFloat(montoRecibido) - montoRestante;
      const nuevoTotalPagado   = parseFloat(cr['Monto_Total_Pagado'] || 0) + montoAplicado;
      const nuevoSaldo         = parseFloat(cr['Precio_Credito_Snap']) - nuevoTotalPagado;
      const semanasPagadas     = _contarSemanasPagadas(pagosRows);
      const semanasConInteres  = _contarSemanasConInteres(pagosRows);
      const estadoOperativo    = _calcEstadoOperativo(pagosRows, hoy);
      const creditoFinalizado  = _verificarFinalizacion(pagosRows);

      const updatesCredito = {
        'Monto_Total_Pagado':  _round2(nuevoTotalPagado),
        'Saldo_Pendiente':     _round2(Math.max(nuevoSaldo, 0)),
        'Semanas_Pagadas':     semanasPagadas,
        'Semanas_Con_Interes': semanasConInteres,
        'Estado_Operativo':    estadoOperativo,
      };

      if (creditoFinalizado) {
        updatesCredito['Estado'] = 'FINALIZADO';
        updatesCredito['Estado_Operativo'] = 'AL_CORRIENTE';
      }

      SheetHelper.updateRow(CONFIG.SHEETS.CREDITOS, creditoFound.rowIndex, updatesCredito);

      // ── 4. Registrar en Caja (si es pago en caja) ─────────
      let movimientoCaja = null;
      if (canal === 'CAJA') {
        movimientoCaja = Caja.registrarIngresoPago(idCredito, montoAplicado, ctx);
      }

      // ── 5. Actualizar Score del cliente ───────────────────
      Score.actualizar(cr['ID_Cliente']);

      // ── 6. Generar ticket ─────────────────────────────────
      const ticket = Tickets.generate({ idCredito, afectados, montoAplicado, montoSobrante: montoRestante }, ctx);

      _log(ctx, 'PAGO_REGISTRAR', 'PAGOS', idCredito, { montoAplicado, tipoAbono, estadoOperativo }, 'EXITO');

      return {
        ok: true,
        montoAplicado: _round2(montoAplicado),
        montoSobrante: _round2(montoRestante),
        estadoOperativo,
        semanasPagadas,
        saldoPendiente: _round2(Math.max(nuevoSaldo, 0)),
        finalizado: creditoFinalizado,
        ticket: ticket.data || null,
        message: `Pago de $${_round2(montoAplicado)} registrado correctamente.`,
      };

    } finally { lock.releaseLock(); }
  }

  // ══════════════════════════════════════════════════════════
  // CASCADA DE APLICACIÓN (Regular)
  // ══════════════════════════════════════════════════════════

  function _aplicarCascada(pagosRows, hoy, montoRestante, ctx, now, canal, afectados) {
    // Clasificar pagos
    const atrasadas = pagosRows.filter(p =>
      (p.data['Estado_Pago'] === 'ATRASADO' ||
       (p.data['Estado_Pago'] === 'POR COBRAR' && p.data['Fecha_Vencimiento'] < hoy)) &&
      parseFloat(p.data['Monto_Pagado'] || 0) < parseFloat(p.data['Monto_Esperado'])
    ).sort((a, b) => a.data['Num_Semana'] - b.data['Num_Semana']);

    const porCobrar = pagosRows.filter(p =>
      p.data['Estado_Pago'] === 'POR COBRAR' &&
      p.data['Fecha_Vencimiento'] >= hoy &&
      parseFloat(p.data['Monto_Pagado'] || 0) < parseFloat(p.data['Monto_Esperado'])
    ).sort((a, b) => a.data['Num_Semana'] - b.data['Num_Semana']);

    const cola = [...atrasadas, ...porCobrar];

    for (const pagoRow of cola) {
      if (montoRestante <= 0) break;
      montoRestante = _aplicarAbonoPago(pagoRow, montoRestante, hoy, ctx, now, canal, 'REGULAR', afectados);
    }

    return montoRestante;
  }

  // ══════════════════════════════════════════════════════════
  // ABONO A CAPITAL
  // ══════════════════════════════════════════════════════════

  /**
   * Condición: mínimo 10 semanas completadas CON INTERÉS.
   * Dirección: desde la ÚLTIMA cuota hacia atrás.
   * El capital se aplica sobre Monto_Pagado, marcando Tipo_Pago = CAPITAL.
   * Cuando Monto_Pagado >= Monto_Esperado → cuota queda "liquidada" (PUNTUAL/NORMAL/MOROSO).
   * Monto_Esperado NUNCA se toca.
   */
  function _aplicarCapital(pagosRows, cr, montoRestante, ctx, now, canal, afectados) {
    const semanasConInteres = parseInt(cr['Semanas_Con_Interes'] || 0);
    if (semanasConInteres < 10) {
      throw { code: 'CAPITAL_NO_PERMITIDO', message: `Se requieren 10 cuotas regulares completadas. Actualmente: ${semanasConInteres}.` };
    }

    // Cuotas que aún no están liquidadas (Monto_Pagado < Monto_Esperado), de fin a inicio
    const pendientes = pagosRows
      .filter(p => parseFloat(p.data['Monto_Pagado'] || 0) < parseFloat(p.data['Monto_Esperado']))
      .sort((a, b) => b.data['Num_Semana'] - a.data['Num_Semana']); // invertido

    const hoy = _today();
    for (const pagoRow of pendientes) {
      if (montoRestante <= 0) break;
      montoRestante = _aplicarAbonoPago(pagoRow, montoRestante, hoy, ctx, now, canal, 'CAPITAL', afectados);
    }

    return montoRestante;
  }

  // ══════════════════════════════════════════════════════════
  // APLICAR ABONO A UNA CUOTA INDIVIDUAL
  // ══════════════════════════════════════════════════════════

  function _aplicarAbonoPago(pagoRow, montoRestante, hoy, ctx, now, canal, tipo, afectados) {
    const p              = pagoRow.data;
    const montoPagado    = parseFloat(p['Monto_Pagado'] || 0);
    const montoEsperado  = parseFloat(p['Monto_Esperado']);
    const faltante       = _round2(montoEsperado - montoPagado);
    if (faltante <= 0) return montoRestante; // ya pagada

    const abono          = Math.min(montoRestante, faltante);
    const nuevoMontoPagado = _round2(montoPagado + abono);
    const liquidada      = nuevoMontoPagado >= montoEsperado;
    const esParcial      = !liquidada;

    // Calcular estado del pago
    let estadoPago = p['Estado_Pago'];
    if (liquidada) {
      const venc = p['Fecha_Vencimiento'];
      const diasAtraso = _diasEntre(venc, hoy);
      if (diasAtraso <= 0)       estadoPago = 'PUNTUAL';
      else if (diasAtraso <= 7)  estadoPago = 'NORMAL';
      else                       estadoPago = 'MOROSO';
    } else {
      estadoPago = (p['Fecha_Vencimiento'] < hoy) ? 'ATRASADO' : 'POR COBRAR';
    }

    const updates = {
      'Monto_Pagado':       nuevoMontoPagado,
      'Estado_Pago':        estadoPago,
      'Es_Parcial':         esParcial ? 'TRUE' : 'FALSE',
      'Tipo_Pago':          tipo,
      'Fecha_Ultimo_Abono': now,
      'Canal_Cobro':        canal,
      'Registrado_Por':     ctx.user.id || ctx.user.username,
    };
    if (!p['Fecha_Primer_Abono']) updates['Fecha_Primer_Abono'] = now;

    SheetHelper.updateRow(CONFIG.SHEETS.PAGOS, pagoRow.rowIndex, updates);

    // Actualizar objeto en memoria
    pagoRow.data = Object.assign({}, p, updates);

    afectados.push({ semana: p['Num_Semana'], abono: _round2(abono), estadoPago, liquidada });
    return _round2(montoRestante - abono);
  }

  // ══════════════════════════════════════════════════════════
  // PAGO EN CAMPO (Cobranza)
  // ══════════════════════════════════════════════════════════

  function _procesarPagoEnCampo(payload, ctx) {
    const { idCredito, montoRecibido, notas } = payload;
    if (!idCredito || !montoRecibido || montoRecibido <= 0) {
      throw { code: 'DATOS_INVALIDOS', message: 'idCredito y montoRecibido son requeridos.' };
    }

    const creditoFound = SheetHelper.findOne(CONFIG.SHEETS.CREDITOS, r => r['ID_Credito'] === idCredito);
    if (!creditoFound) throw { code: 'NO_ENCONTRADO', message: 'Crédito no encontrado.' };
    if (creditoFound.data['Estado'] !== 'ACTIVO') throw { code: 'CREDITO_NO_ACTIVO', message: 'Crédito no activo.' };

    const now            = _now();
    const idCobranza     = 'COB' + Date.now();
    const fechaLimite    = _addHoras(new Date(), CONFIG.COBRANZA_ALERTA_HORAS);

    // Registrar en hoja Cobranza como PENDIENTE_DEPOSITO
    SheetHelper.insertRow(CONFIG.SHEETS.COBRANZA, {
      'ID_Cobranza':        idCobranza,
      'ID_Credito':         idCredito,
      'ID_Cliente':         creditoFound.data['ID_Cliente'],
      'ID_Pago':            '',             // se asignará al confirmar depósito
      'Responsable_ID':     ctx.user.id || ctx.user.username,
      'Monto_Cobrado':      parseFloat(montoRecibido),
      'Fecha_Cobro':        now,
      'Estado':             'PENDIENTE_DEPOSITO',
      'Fecha_Limite_Dep':   Utilities.formatDate(fechaLimite, CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'),
      'Fecha_Deposito':     '',
      'Confirmado_Por':     '',
      'Notas':              notas || '',
    });

    _log(ctx, 'PAGO_CAMPO', 'PAGOS', idCredito, { idCobranza, monto: montoRecibido, estado: 'PENDIENTE_DEPOSITO' }, 'EXITO');
    return {
      ok: true,
      idCobranza,
      message: `Cobro de $${montoRecibido} registrado. Pendiente de depósito en caja.`,
      fechaLimite: Utilities.formatDate(fechaLimite, CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'),
    };
  }

  // ══════════════════════════════════════════════════════════
  // CONFIRMAR DEPÓSITO EN CAJA
  // ══════════════════════════════════════════════════════════

  function _confirmarDeposito(payload, ctx) {
    const { idCobranza } = payload;
    if (!idCobranza) throw { code: 'DATOS_INVALIDOS', message: 'idCobranza requerido.' };

    const lock = LockService.getScriptLock();
    lock.waitLock(15000);
    try {
      const cobranzaFound = SheetHelper.findOne(CONFIG.SHEETS.COBRANZA, r => r['ID_Cobranza'] === idCobranza);
      if (!cobranzaFound) throw { code: 'NO_ENCONTRADO', message: 'Registro de cobranza no encontrado.' };
      const cob = cobranzaFound.data;

      if (cob['Estado'] !== 'PENDIENTE_DEPOSITO') {
        throw { code: 'ESTADO_INVALIDO', message: 'Este cobro ya fue procesado.' };
      }

      // Aplicar el pago al motor de pagos
      const resultado = _procesarPago({
        idCredito:     cob['ID_Credito'],
        montoRecibido: parseFloat(cob['Monto_Cobrado']),
        tipoAbono:     'REGULAR',
      }, ctx, 'CAMPO');

      // Actualizar registro de cobranza
      SheetHelper.updateRow(CONFIG.SHEETS.COBRANZA, cobranzaFound.rowIndex, {
        'Estado':         'DEPOSITADO',
        'Fecha_Deposito': _now(),
        'Confirmado_Por': ctx.user.id || ctx.user.username,
      });

      _log(ctx, 'PAGO_CONFIRMAR', 'PAGOS', cob['ID_Credito'], { idCobranza, monto: cob['Monto_Cobrado'] }, 'EXITO');
      return Object.assign({ ok: true, idCobranza }, resultado);

    } finally { lock.releaseLock(); }
  }

  // ══════════════════════════════════════════════════════════
  // HELPERS INTERNOS
  // ══════════════════════════════════════════════════════════

  function _contarSemanasPagadas(pagosRows) {
    return pagosRows.filter(p =>
      parseFloat(p.data['Monto_Pagado'] || 0) >= parseFloat(p.data['Monto_Esperado'])
    ).length;
  }

  function _contarSemanasConInteres(pagosRows) {
    return pagosRows.filter(p =>
      p.data['Tipo_Pago'] === 'REGULAR' &&
      parseFloat(p.data['Monto_Pagado'] || 0) >= parseFloat(p.data['Monto_Esperado'])
    ).length;
  }

  function _calcEstadoOperativo(pagosRows, hoy) {
    const atrasadas = pagosRows.filter(p =>
      (p.data['Estado_Pago'] === 'ATRASADO') ||
      (p.data['Estado_Pago'] === 'POR COBRAR' && p.data['Fecha_Vencimiento'] < hoy &&
       parseFloat(p.data['Monto_Pagado'] || 0) < parseFloat(p.data['Monto_Esperado']))
    ).length;

    if (atrasadas === 0) return 'AL_CORRIENTE';
    if (atrasadas === 1) return 'ATRASO_LEVE';
    return 'ATRASO_CRITICO';
  }

  function _verificarFinalizacion(pagosRows) {
    return pagosRows.every(p =>
      parseFloat(p.data['Monto_Pagado'] || 0) >= parseFloat(p.data['Monto_Esperado'])
    );
  }

  function _calcResumen(pagos) {
    const total    = pagos.length;
    const pagadas  = pagos.filter(p => ['PUNTUAL','NORMAL','MOROSO'].includes(p['Estado_Pago'])).length;
    const atrasadas= pagos.filter(p => p['Estado_Pago'] === 'ATRASADO').length;
    const pendientes= pagos.filter(p => p['Estado_Pago'] === 'POR COBRAR').length;
    return { total, pagadas, atrasadas, pendientes };
  }

  function _diasEntre(fechaStr, hoy) {
    const f1 = new Date(fechaStr + 'T00:00:00');
    const f2 = new Date(hoy + 'T00:00:00');
    return Math.floor((f2 - f1) / (1000 * 60 * 60 * 24));
  }

  function _today() {
    return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd');
  }

  function _addHoras(date, horas) {
    return new Date(date.getTime() + horas * 60 * 60 * 1000);
  }

  function _round2(n) { return Math.round(n * 100) / 100; }
  function _now() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'); }

  function _log(ctx, accion, modulo, id, detalle, resultado) {
    try {
      SheetHelper.insertRow(CONFIG.SHEETS.LOGS, {
        'ID_Log': 'LOG' + Date.now(), 'Timestamp': _now(),
        'Usuario_ID': ctx.user.id || '', 'Username': ctx.user.username || '',
        'Accion': accion, 'Modulo': modulo, 'ID_Registro_Afectado': id,
        'Estado_Anterior': '', 'Estado_Nuevo': JSON.stringify(detalle),
        'IP_Origen': ctx.ip || '', 'Resultado': resultado, 'Detalle_Error': '',
      });
    } catch(_) {}
  }

  return { register, registerField, confirmDeposit, getSchedule };
})();
