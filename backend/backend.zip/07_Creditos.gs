// ============================================================
// CredyFast — 07_Creditos.gs
// Módulo de créditos: solicitud, aprobación, rechazo y consulta.
// ============================================================

const Creditos = (() => {

  // ── Solicitar crédito ─────────────────────────────────────
  function request(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.VENDEDOR);
      const { idCliente, idProducto, notas } = payload;
      if (!idCliente || !idProducto) throw { code: 'DATOS_INVALIDOS', message: 'idCliente e idProducto son requeridos.' };

      // Validar cliente
      const clienteFound = SheetHelper.findOne(CONFIG.SHEETS.CLIENTES, r => r['ID_Cliente'] === idCliente);
      if (!clienteFound) throw { code: 'CLIENTE_NO_ENCONTRADO', message: 'Cliente no encontrado.' };
      const cliente = clienteFound.data;
      if (cliente['Activo'] !== true && cliente['Activo'] !== 'TRUE')
        throw { code: 'CLIENTE_INACTIVO', message: 'El cliente está inactivo.' };
      if (cliente['Documentos_Completos'] !== true && cliente['Documentos_Completos'] !== 'TRUE')
        throw { code: 'DOCS_INCOMPLETOS', message: 'El cliente no tiene documentos completos.' };

      // Validar producto
      const prodFound = SheetHelper.findOne(CONFIG.SHEETS.PRODUCTOS, r => r['ID_Producto'] === idProducto);
      if (!prodFound) throw { code: 'PRODUCTO_NO_ENCONTRADO', message: 'Producto no encontrado.' };
      if (prodFound.data['Activo'] !== true && prodFound.data['Activo'] !== 'TRUE')
        throw { code: 'PRODUCTO_INACTIVO', message: 'El producto está inactivo.' };

      // No puede tener otro crédito ACTIVO
      const creditoActivo = SheetHelper.findOne(CONFIG.SHEETS.CREDITOS,
        r => r['ID_Cliente'] === idCliente && r['Estado'] === 'ACTIVO');
      if (creditoActivo) throw { code: 'CREDITO_ACTIVO_EXISTENTE', message: 'El cliente ya tiene un crédito activo.' };

      const lock = LockService.getScriptLock();
      lock.waitLock(10000);
      try {
        const id  = SheetHelper.nextId(CONFIG.SHEETS.CREDITOS, 'IDCR', 4);
        const now = _now();
        const prod = prodFound.data;

        SheetHelper.insertRow(CONFIG.SHEETS.CREDITOS, {
          'ID_Credito':          id,
          'ID_Cliente':          idCliente,
          'ID_Producto':         idProducto,
          'Estado':              'PENDIENTE',
          'Estado_Operativo':    '',
          'Fecha_Solicitud':     now,
          'Fecha_Aprobacion':    '',
          'Fecha_Inicio':        '',
          'Fecha_Fin_Estimada':  '',
          'Precio_Contado_Snap': prod['Precio_Contado'],
          'Precio_Credito_Snap': prod['Precio_Credito'],
          'Costo_Producto_Snap': prod['Costo_Producto'],
          'Total_Semanas':       prod['Total_Semanas'],
          'Pago_Semanal':        prod['Pago_Semanal'],
          'Cuota_Capital_Base':  _round2(prod['Precio_Contado'] / prod['Total_Semanas']),
          'Semanas_Pagadas':     0,
          'Semanas_Con_Interes': 0,
          'Monto_Total_Pagado':  0,
          'Saldo_Pendiente':     prod['Precio_Credito'],
          'Vendedor_ID':         ctx.user.id || ctx.user.username,
          'Aprobado_Por':        '',
          'Rechazado_Por':       '',
          'Motivo_Rechazo':      '',
          'Drive_Folder_ID':     '',
          'Contrato_PDF_ID':     '',
          'Entrega_Foto_ID':     '',
          'Notas':               notas || '',
        });

        _log(ctx, 'CREDITO_SOLICITAR', id, { idCliente, idProducto }, 'EXITO');
        return { ok: true, id, message: `Solicitud de crédito ${id} creada. En espera de aprobación.` };

      } finally { lock.releaseLock(); }
    } catch (err) { return handleError_(err); }
  }

  // ── Aprobar crédito ───────────────────────────────────────
  function approve(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPERVISOR);
      const { idCredito } = payload;
      if (!idCredito) throw { code: 'DATOS_INVALIDOS', message: 'idCredito requerido.' };

      const lock = LockService.getScriptLock();
      lock.waitLock(15000);
      try {
        const found = SheetHelper.findOne(CONFIG.SHEETS.CREDITOS, r => r['ID_Credito'] === idCredito);
        if (!found) throw { code: 'NO_ENCONTRADO', message: 'Crédito no encontrado.' };

        // Control de concurrencia: solo desde PENDIENTE
        if (found.data['Estado'] !== 'PENDIENTE') {
          throw { code: 'ESTADO_INVALIDO', message: `El crédito ya fue procesado (estado: ${found.data['Estado']}).` };
        }

        const cr  = found.data;
        const now = _now();
        const fechaInicio = _calcFechaInicio(new Date());

        // Generar N filas de Pagos
        _generarCalendarioPagos(cr, idCredito, fechaInicio, ctx);

        // Crear carpeta en Drive
        const folder = DriveApp.getFolderById(CONFIG.DRIVE_CREDITOS_FOLDER_ID)
          .createFolder(idCredito + '_' + cr['ID_Cliente']);
        const folderId = folder.getId();

        // Actualizar Crédito → ACTIVO
        const fechaFin = _addDays(fechaInicio, (parseInt(cr['Total_Semanas']) - 1) * 7);
        SheetHelper.updateRow(CONFIG.SHEETS.CREDITOS, found.rowIndex, {
          'Estado':           'ACTIVO',
          'Estado_Operativo': 'AL_CORRIENTE',
          'Fecha_Aprobacion': now,
          'Fecha_Inicio':     _dateStr(fechaInicio),
          'Fecha_Fin_Estimada': _dateStr(fechaFin),
          'Aprobado_Por':     ctx.user.id || ctx.user.username,
          'Drive_Folder_ID':  folderId,
          'Saldo_Pendiente':  cr['Precio_Credito_Snap'],
          'Semanas_Pagadas':  0,
          'Semanas_Con_Interes': 0,
        });

        // Inicializar Score del cliente si no existe
        Score.initIfNotExists(cr['ID_Cliente']);

        _log(ctx, 'CREDITO_APROBAR', idCredito, { estado: 'ACTIVO', fechaInicio: _dateStr(fechaInicio) }, 'EXITO');
        return { ok: true, idCredito, fechaInicio: _dateStr(fechaInicio), folderId, message: `Crédito ${idCredito} aprobado.` };

      } finally { lock.releaseLock(); }
    } catch (err) { return handleError_(err); }
  }

  // ── Rechazar crédito ──────────────────────────────────────
  function reject(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPERVISOR);
      const { idCredito, motivo } = payload;
      if (!idCredito) throw { code: 'DATOS_INVALIDOS', message: 'idCredito requerido.' };

      const lock = LockService.getScriptLock();
      lock.waitLock(10000);
      try {
        const found = SheetHelper.findOne(CONFIG.SHEETS.CREDITOS, r => r['ID_Credito'] === idCredito);
        if (!found) throw { code: 'NO_ENCONTRADO', message: 'Crédito no encontrado.' };
        if (found.data['Estado'] !== 'PENDIENTE') {
          throw { code: 'ESTADO_INVALIDO', message: 'Solo se pueden rechazar créditos en estado PENDIENTE.' };
        }

        SheetHelper.updateRow(CONFIG.SHEETS.CREDITOS, found.rowIndex, {
          'Estado':        'RECHAZADO',
          'Rechazado_Por': ctx.user.id || ctx.user.username,
          'Motivo_Rechazo': motivo || 'Sin motivo especificado.',
        });

        _log(ctx, 'CREDITO_RECHAZAR', idCredito, { motivo }, 'EXITO');
        return { ok: true, message: `Crédito ${idCredito} rechazado.` };

      } finally { lock.releaseLock(); }
    } catch (err) { return handleError_(err); }
  }

  // ── Listar créditos ───────────────────────────────────────
  function list(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.VENDEDOR);
      const { estado, idCliente } = payload || {};
      let all = SheetHelper.getAll(CONFIG.SHEETS.CREDITOS);

      // Vendedor solo ve sus propios créditos
      if (ctx.user.rol === CONFIG.ROLES.VENDEDOR) {
        all = all.filter(r => r['Vendedor_ID'] === (ctx.user.id || ctx.user.username));
      }
      if (estado) all = all.filter(r => r['Estado'] === estado);
      if (idCliente) all = all.filter(r => r['ID_Cliente'] === idCliente);

      return { ok: true, data: all };
    } catch (err) { return handleError_(err); }
  }

  // ── Obtener crédito individual ────────────────────────────
  function get(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.VENDEDOR);
      const { id } = payload;
      const found = SheetHelper.findOne(CONFIG.SHEETS.CREDITOS, r => r['ID_Credito'] === id);
      if (!found) throw { code: 'NO_ENCONTRADO', message: 'Crédito no encontrado.' };

      // Obtener calendario de pagos
      const pagos = SheetHelper.findRows(CONFIG.SHEETS.PAGOS, r => r['ID_Credito'] === id)
        .map(p => p.data)
        .sort((a, b) => a['Num_Semana'] - b['Num_Semana']);

      return { ok: true, data: found.data, pagos };
    } catch (err) { return handleError_(err); }
  }

  // ── Helpers internos ──────────────────────────────────────

  /**
   * Genera N filas en la hoja Pagos según el calendario del crédito.
   */
  function _generarCalendarioPagos(cr, idCredito, fechaInicio, ctx) {
    const n          = parseInt(cr['Total_Semanas']);
    const monto      = parseFloat(cr['Pago_Semanal']);
    const idCliente  = cr['ID_Cliente'];

    for (let i = 1; i <= n; i++) {
      const fechaVenc = _addDays(fechaInicio, (i - 1) * 7);
      const idPago    = SheetHelper.nextId(CONFIG.SHEETS.PAGOS, 'IDPG', 6);

      SheetHelper.insertRow(CONFIG.SHEETS.PAGOS, {
        'ID_Pago':           idPago,
        'ID_Credito':        idCredito,
        'ID_Cliente':        idCliente,
        'Num_Semana':        i,
        'Fecha_Vencimiento': _dateStr(fechaVenc),
        'Monto_Esperado':    monto,
        'Monto_Pagado':      0,
        'Estado_Pago':       'POR COBRAR',
        'Es_Parcial':        'FALSE',
        'Tipo_Pago':         'REGULAR',
        'Fecha_Primer_Abono': '',
        'Fecha_Ultimo_Abono': '',
        'Canal_Cobro':        '',
        'Registrado_Por':     '',
        'Confirmado_Por':     '',
        'Notas':              '',
      });
    }
  }

  /**
   * Regla de calendario: determina la Fecha_Inicio según el día de aprobación.
   * Lun-Mié (1-3): mismo día de semana en 7 días
   * Jue-Vie (4-5): próximo Lunes + 7 días
   * Sáb-Dom (0,6): próximo Martes + 7 días
   */
  function _calcFechaInicio(hoy) {
    const dow = hoy.getDay(); // 0=Dom, 1=Lun ... 6=Sáb
    let diasHastaBase;

    if (dow >= 1 && dow <= 3) {
      diasHastaBase = 7; // mismo día de semana siguiente
    } else if (dow === 4 || dow === 5) {
      const diasHastaLunes = (8 - dow) % 7 || 7;
      diasHastaBase = diasHastaLunes + 7; // siguiente Lunes + 7
    } else {
      // Sábado(6) o Domingo(0)
      const diasHastaMartes = dow === 6 ? 2 : 2; // Sáb→2días=Lun, Dom→2días=Mar
      diasHastaBase = diasHastaMartes + 7;
    }
    return _addDays(hoy, diasHastaBase);
  }

  function _addDays(date, days) {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    return d;
  }

  function _dateStr(date) {
    return Utilities.formatDate(date, CONFIG.TIMEZONE, 'yyyy-MM-dd');
  }

  function _round2(n) { return Math.round(n * 100) / 100; }
  function _now() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'); }

  function _log(ctx, accion, id, detalle, resultado) {
    try {
      SheetHelper.insertRow(CONFIG.SHEETS.LOGS, {
        'ID_Log': 'LOG' + Date.now(), 'Timestamp': _now(),
        'Usuario_ID': ctx.user.id || '', 'Username': ctx.user.username || '',
        'Accion': accion, 'Modulo': 'CREDITOS', 'ID_Registro_Afectado': id,
        'Estado_Anterior': '', 'Estado_Nuevo': JSON.stringify(detalle),
        'IP_Origen': ctx.ip || '', 'Resultado': resultado, 'Detalle_Error': '',
      });
    } catch(_) {}
  }

  return { request, approve, reject, list, get };
})();
