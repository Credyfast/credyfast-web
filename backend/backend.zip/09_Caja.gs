// ============================================================
// CredyFast — 09_Caja.gs
// Módulo de Caja: ingresos, retiros y saldo.
// ============================================================

const Caja = (() => {

  // ── Saldo actual ──────────────────────────────────────────
  function getBalance(ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.CAJERO);
      const saldo = _getSaldoActual();
      return { ok: true, saldo };
    } catch (err) { return handleError_(err); }
  }

  // ── Movimientos recientes ─────────────────────────────────
  function movements(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.CAJERO);
      const { limite, fecha } = payload || {};
      let movs = SheetHelper.getAll(CONFIG.SHEETS.CAJA);
      if (fecha) movs = movs.filter(m => m['Fecha'] && m['Fecha'].startsWith(fecha));
      movs.sort((a, b) => new Date(b['Fecha']) - new Date(a['Fecha']));
      return { ok: true, data: movs.slice(0, limite || 50) };
    } catch (err) { return handleError_(err); }
  }

  // ── Registrar ingreso de pago (llamado por MotorPagos) ────
  function registrarIngresoPago(idCredito, monto, ctx) {
    const saldoAnterior = _getSaldoActual();
    const saldoPosterior = _round2(saldoAnterior + monto);
    const id = 'MOV' + Date.now();

    SheetHelper.insertRow(CONFIG.SHEETS.CAJA, {
      'ID_Movimiento':  id,
      'Tipo':           'INGRESO_PAGO',
      'Monto':          _round2(monto),
      'ID_Referencia':  idCredito,
      'Concepto':       `Pago de crédito ${idCredito}`,
      'Saldo_Anterior': saldoAnterior,
      'Saldo_Posterior':saldoPosterior,
      'Registrado_Por': ctx.user.id || ctx.user.username,
      'Autorizado_Por': '',
      'Fecha':          _now(),
      'Estado':         'CONFIRMADO',
    });

    return { id, saldoAnterior, saldoPosterior };
  }

  // ── Retiro de caja ────────────────────────────────────────
  function withdrawal(payload, ctx) {
    try {
      requireRole_(ctx.user.rol, CONFIG.ROLES.SUPERVISOR);
      const { monto, concepto, autorizadoPor } = payload;
      if (!monto || monto <= 0) throw { code: 'DATOS_INVALIDOS', message: 'Monto de retiro inválido.' };

      const lock = LockService.getScriptLock();
      lock.waitLock(10000);
      try {
        const saldoActual = _getSaldoActual();
        if (monto > saldoActual) throw { code: 'SALDO_INSUFICIENTE', message: 'No hay suficiente saldo en caja.' };

        const saldoPosterior = _round2(saldoActual - monto);
        const id = 'MOV' + Date.now();

        SheetHelper.insertRow(CONFIG.SHEETS.CAJA, {
          'ID_Movimiento':  id,
          'Tipo':           'RETIRO',
          'Monto':          _round2(monto),
          'ID_Referencia':  '',
          'Concepto':       concepto || 'Retiro de caja',
          'Saldo_Anterior': saldoActual,
          'Saldo_Posterior':saldoPosterior,
          'Registrado_Por': ctx.user.id || ctx.user.username,
          'Autorizado_Por': autorizadoPor || ctx.user.id || ctx.user.username,
          'Fecha':          _now(),
          'Estado':         'CONFIRMADO',
        });

        _log(ctx, 'CAJA_RETIRO', id, { monto, saldoAnterior: saldoActual, saldoPosterior }, 'EXITO');
        return { ok: true, id, saldoPosterior, message: `Retiro de $${_round2(monto)} registrado.` };

      } finally { lock.releaseLock(); }
    } catch (err) { return handleError_(err); }
  }

  // ── Apertura de caja ──────────────────────────────────────
  function abrirCaja(montoInicial, ctx) {
    const id = 'MOV' + Date.now();
    SheetHelper.insertRow(CONFIG.SHEETS.CAJA, {
      'ID_Movimiento':  id,
      'Tipo':           'APERTURA_CAJA',
      'Monto':          _round2(montoInicial),
      'ID_Referencia':  '',
      'Concepto':       'Apertura de caja',
      'Saldo_Anterior': 0,
      'Saldo_Posterior':_round2(montoInicial),
      'Registrado_Por': ctx.user.id || ctx.user.username,
      'Autorizado_Por': '',
      'Fecha':          _now(),
      'Estado':         'CONFIRMADO',
    });
    return { id, saldoPosterior: montoInicial };
  }

  // ── Helpers internos ──────────────────────────────────────

  function _getSaldoActual() {
    const ultimoSaldo = SheetHelper.getLastColumnValue(CONFIG.SHEETS.CAJA, 7); // Columna G = Saldo_Posterior
    return parseFloat(ultimoSaldo || 0);
  }

  function _round2(n) { return Math.round(n * 100) / 100; }
  function _now() { return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'); }

  function _log(ctx, accion, id, detalle, resultado) {
    try {
      SheetHelper.insertRow(CONFIG.SHEETS.LOGS, {
        'ID_Log': 'LOG' + Date.now(), 'Timestamp': _now(),
        'Usuario_ID': ctx.user.id || '', 'Username': ctx.user.username || '',
        'Accion': accion, 'Modulo': 'CAJA', 'ID_Registro_Afectado': id,
        'Estado_Anterior': '', 'Estado_Nuevo': JSON.stringify(detalle),
        'IP_Origen': ctx.ip || '', 'Resultado': resultado, 'Detalle_Error': '',
      });
    } catch(_) {}
  }

  return { getBalance, movements, registrarIngresoPago, withdrawal, abrirCaja };
})();
