// ============================================================
// CredyFast — 00_Config.gs
// Configuración central. Editar con cuidado.
// ============================================================

const CONFIG = {
  // ── IDs de Google Sheets ─────────────────────────────────
  SPREADSHEET_ID: 'REEMPLAZAR_CON_ID_DE_TU_SPREADSHEET',

  // ── IDs de Google Drive ──────────────────────────────────
  DRIVE_ROOT_FOLDER_ID:     'REEMPLAZAR_CON_ID_CARPETA_CREDYFAST',
  DRIVE_CLIENTES_FOLDER_ID: 'REEMPLAZAR_CON_ID_CARPETA_CLIENTES',
  DRIVE_CREDITOS_FOLDER_ID: 'REEMPLAZAR_CON_ID_CARPETA_CREDITOS',
  DRIVE_PLANTILLAS_FOLDER_ID: 'REEMPLAZAR_CON_ID_CARPETA_PLANTILLAS',
  CONTRATO_TEMPLATE_ID:     'REEMPLAZAR_CON_ID_PLANTILLA_CONTRATO_DOCS',

  // ── Sesiones ─────────────────────────────────────────────
  SESSION_DURATION_HOURS: 8,
  SESSION_CACHE_PREFIX: 'sess_',

  // ── SuperUsuarios hardcoded ───────────────────────────────
  // NUNCA se pueden crear/editar/eliminar desde la UI
  SUPER_USERS: [
    { username: 'MauricioMC', passwordHash: '5e2fb94143a7ff3e60dc45d7b8f527ce31ba3fc5af8a72c6f6e6a0e8ddb37ba5' }, // Credyfast2026
    { username: 'JesusDC',    passwordHash: '5e2fb94143a7ff3e60dc45d7b8f527ce31ba3fc5af8a72c6f6e6a0e8ddb37ba5' },
    { username: 'MartinMC',   passwordHash: '5e2fb94143a7ff3e60dc45d7b8f527ce31ba3fc5af8a72c6f6e6a0e8ddb37ba5' },
  ],

  // ── Roles ─────────────────────────────────────────────────
  ROLES: {
    SUPER_USUARIO: 'SuperUsuario',
    SUPERVISOR:    'Supervisor',
    VENDEDOR:      'Vendedor',
    CAJERO:        'Cajero',
    COBRANZA:      'Cobranza',
  },

  // ── Jerarquía de roles (para comparaciones de permisos) ───
  ROLE_LEVEL: {
    'SuperUsuario': 5,
    'Supervisor':   4,
    'Vendedor':     3,
    'Cajero':       2,
    'Cobranza':     1,
  },

  // ── Nombres de hojas ─────────────────────────────────────
  SHEETS: {
    USUARIOS:      'Usuarios',
    PRODUCTOS:     'Productos',
    CLIENTES:      'Clientes',
    CREDITOS:      'Creditos',
    PAGOS:         'Pagos',
    CAJA:          'Caja',
    ARQUEOS_CAJA:  'Arqueos_Caja',
    LOGS:          'Logs',
    SCORE_CLIENTE: 'Score_Cliente',
    COBRANZA:      'Cobranza',     // ← nuevo en Fase 3
  },

  // ── Cobranza en campo ────────────────────────────────────
  COBRANZA_ALERTA_HORAS: 24,      // Alerta si no se deposita en 24h

  // ── Zona horaria ─────────────────────────────────────────
  TIMEZONE: 'America/Mexico_City',
};

// ── Columnas de Cobranza (hoja nueva) ────────────────────────
const COL_COBRANZA = {
  ID_COBRANZA:         1,  // A
  ID_CREDITO:          2,  // B
  ID_CLIENTE:          3,  // C
  ID_PAGO:             4,  // D
  RESPONSABLE_ID:      5,  // E  — FK Usuarios (cobranza)
  MONTO_COBRADO:       6,  // F
  FECHA_COBRO:         7,  // G
  ESTADO:              8,  // H  — PENDIENTE_DEPOSITO / DEPOSITADO / ALERTA
  FECHA_LIMITE_DEP:    9,  // I  — Fecha_Cobro + 24h
  FECHA_DEPOSITO:     10,  // J  — cuando cajero confirma
  CONFIRMADO_POR:     11,  // K  — FK Usuarios (cajero)
  NOTAS:              12,  // L
};
