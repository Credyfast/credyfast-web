// ============================================================
// CredyFast — 17_Setup.gs
// Script de inicialización única del sistema.
// EJECUTAR UNA SOLA VEZ después de crear el Spreadsheet.
// ============================================================

/**
 * Función principal de setup. Crear todas las hojas con sus encabezados.
 * Ejecutar desde el editor de Apps Script: Ejecutar → setupSistema
 */
function setupSistema() {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  Logger.log('=== CredyFast Setup iniciado ===');

  _crearHoja(ss, CONFIG.SHEETS.USUARIOS, [
    'ID_Usuario','Username','Password_Hash','Nombre_Completo','Rol',
    'Activo','Fecha_Creacion','Creado_Por','Ultimo_Acceso','Notas',
  ]);

  _crearHoja(ss, CONFIG.SHEETS.PRODUCTOS, [
    'ID_Producto','Nombre','Descripcion','Categoria','Marca','Modelo',
    'Costo_Producto','Precio_Contado','Precio_Credito','Total_Semanas',
    'Pago_Semanal','Tasa_Interes_Implicita','Stock_Disponible','Stock_Minimo',
    'Numero_Serie','Proveedor','Activo','Fecha_Creacion','Creado_Por',
    'Fecha_Modificacion','Modificado_Por','Imagen_Drive_ID',
  ]);

  _crearHoja(ss, CONFIG.SHEETS.CLIENTES, [
    'ID_Cliente','Nombre','Apellido_Paterno','Apellido_Materno','CURP',
    'Fecha_Nacimiento','Sexo','Telefono_Principal','Telefono_Secundario',
    'Calle_Numero','Colonia','Ciudad','Estado','CP',
    'Coordenadas_Lat','Coordenadas_Lng',
    'Ref1_Nombre','Ref1_Telefono','Ref1_Relacion',
    'Ref2_Nombre','Ref2_Telefono','Ref2_Relacion',
    'Drive_Folder_ID','INE_Frente_ID','INE_Reverso_ID','Comprobante_ID',
    'Documentos_Completos','Vendedor_ID','Fecha_Registro','Activo','Notas',
  ]);

  _crearHoja(ss, CONFIG.SHEETS.CREDITOS, [
    'ID_Credito','ID_Cliente','ID_Producto','Estado','Estado_Operativo',
    'Fecha_Solicitud','Fecha_Aprobacion','Fecha_Inicio','Fecha_Fin_Estimada',
    'Precio_Contado_Snap','Precio_Credito_Snap','Costo_Producto_Snap',
    'Total_Semanas','Pago_Semanal','Cuota_Capital_Base',
    'Semanas_Pagadas','Semanas_Con_Interes','Monto_Total_Pagado','Saldo_Pendiente',
    'Vendedor_ID','Aprobado_Por','Rechazado_Por','Motivo_Rechazo',
    'Drive_Folder_ID','Contrato_PDF_ID','Entrega_Foto_ID','Notas',
  ]);

  _crearHoja(ss, CONFIG.SHEETS.PAGOS, [
    'ID_Pago','ID_Credito','ID_Cliente','Num_Semana','Fecha_Vencimiento',
    'Monto_Esperado','Monto_Pagado','Estado_Pago','Es_Parcial','Tipo_Pago',
    'Fecha_Primer_Abono','Fecha_Ultimo_Abono','Canal_Cobro',
    'Registrado_Por','Confirmado_Por','Notas',
  ]);

  _crearHoja(ss, CONFIG.SHEETS.CAJA, [
    'ID_Movimiento','Tipo','Monto','ID_Referencia','Concepto',
    'Saldo_Anterior','Saldo_Posterior','Registrado_Por','Autorizado_Por','Fecha','Estado',
  ]);

  _crearHoja(ss, CONFIG.SHEETS.ARQUEOS_CAJA, [
    'ID_Arqueo','Fecha','Realizado_Por','Supervisado_Por','Saldo_Sistema',
    'Billetes_1000','Billetes_500','Billetes_200','Billetes_100','Billetes_50',
    'Monedas_20','Monedas_10','Monedas_5','Monedas_2','Monedas_1','Monedas_050',
    'Total_Fisico','Diferencia','Resultado',
  ]);

  _crearHoja(ss, CONFIG.SHEETS.LOGS, [
    'ID_Log','Timestamp','Usuario_ID','Username','Accion','Modulo',
    'ID_Registro_Afectado','Estado_Anterior','Estado_Nuevo','IP_Origen','Resultado','Detalle_Error',
  ]);

  _crearHoja(ss, CONFIG.SHEETS.SCORE_CLIENTE, [
    'ID_Cliente','Total_Creditos','Creditos_Completados','Creditos_Inconclusos',
    'Creditos_Activos','Total_Pagos','Pagos_Puntuales','Pagos_Normales',
    'Pagos_Morosos','Pagos_Parciales','Semanas_Atraso_Acumuladas',
    'Score_Raw','Clasificacion','Ultima_Actualizacion',
  ]);

  // Hoja de Cobranza (nueva — Fase 3)
  _crearHoja(ss, CONFIG.SHEETS.COBRANZA, [
    'ID_Cobranza','ID_Credito','ID_Cliente','ID_Pago',
    'Responsable_ID','Monto_Cobrado','Fecha_Cobro',
    'Estado','Fecha_Limite_Dep','Fecha_Deposito','Confirmado_Por','Notas',
  ]);

  // Insertar movimiento de apertura inicial de caja (saldo = 0)
  const cajaSheet = ss.getSheetByName(CONFIG.SHEETS.CAJA);
  if (cajaSheet && cajaSheet.getLastRow() <= 1) {
    cajaSheet.appendRow([
      'MOV_INIT', 'APERTURA_CAJA', 0, '', 'Saldo inicial del sistema',
      0, 0, 'SYSTEM', '', _now(), 'CONFIRMADO',
    ]);
    Logger.log('Movimiento inicial de caja creado.');
  }

  Logger.log('=== Setup completado. ' + ss.getNumSheets() + ' hojas configuradas. ===');
  SpreadsheetApp.getUi().alert('✅ CredyFast setup completado correctamente.\n\nRecuerda configurar los IDs de Drive en 00_Config.gs');
}

// ── Helper privado ────────────────────────────────────────────

function _crearHoja(ss, nombre, columnas) {
  let sheet = ss.getSheetByName(nombre);
  if (!sheet) {
    sheet = ss.insertSheet(nombre);
    Logger.log('Hoja creada: ' + nombre);
  } else {
    Logger.log('Hoja ya existe: ' + nombre);
  }

  // Solo escribir encabezados si la hoja está vacía
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, columnas.length).setValues([columnas]);
    // Formato de encabezados
    const headerRange = sheet.getRange(1, 1, 1, columnas.length);
    headerRange.setBackground('#1a73e8');
    headerRange.setFontColor('#ffffff');
    headerRange.setFontWeight('bold');
    sheet.setFrozenRows(1);
    Logger.log('  Encabezados escritos: ' + columnas.length + ' columnas.');
  }
}

function _now() {
  return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss');
}

// ── Función para verificar el estado del setup ────────────────
function verificarSetup() {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  const hojas = Object.values(CONFIG.SHEETS);
  const resultados = hojas.map(nombre => {
    const sheet = ss.getSheetByName(nombre);
    return { hoja: nombre, existe: !!sheet, columnas: sheet ? sheet.getLastColumn() : 0 };
  });
  Logger.log(JSON.stringify(resultados, null, 2));
}
